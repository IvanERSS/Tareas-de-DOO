
package lab04.models;


public class User {
    
    public String usuario;
    public String password;
    public String email;
    public String nombre;
    public String apellidos;
    public String ocupacion;
    
    public User(){
        
        usuario = "Ivan";
        password = "123";
        email = "ivan_ers_1998@hotmail.com";
        nombre = "Ivan Emiliano";
        apellidos = "Rodriguez Salazar";
        ocupacion = "Estudiante";
        
    }
    
    public String toString(){
        return "\n" + usuario + "\n" + email + "\n" + nombre + "\n" + apellidos + "\n" + ocupacion + "\n";
    }
    
    public String obtenerUsuario()
    {
        return usuario;
    }
    
    public String obtenerContrasena()
    {
        return password;
    }
    
    
}
